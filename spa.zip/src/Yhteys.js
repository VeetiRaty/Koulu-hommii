import React, { Component } from "react";
 
class Yhteys extends Component {
  render() {
    return (
      <div>
        <h2>Yhteyden otot</h2>
        <p>Helpoin tapa lähettää sähköpostia <a href="http://forum.abcabc.com">foorumille</a>.
        </p>
      </div>
    );
  }
}
 
export default Yhteys;
