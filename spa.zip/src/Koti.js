import React, { Component } from "react";
 
class Koti extends Component {
  render() {
    return (
      <div>
        <h2>Moikka</h2>
        <p>Tähän tekstiä. Tähän tekstiä. Tähän tekstiä..</p>
      </div>
    );
  }
}
 
export default Koti;
